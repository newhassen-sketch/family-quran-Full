# Family Quran & Islam App 🌙

Made with love by Hassan for Foziya, Jumana & Haniya ❤️

## How to host on GitHub Pages (free)

1. Go to github.com and create a free account
2. Tap "New repository" → name it: family-quran → Public → Create
3. Upload ALL files in this folder (index.html, manifest.json, sw.js, icon-192.png, icon-512.png)
4. Go to Settings → Pages → Source: main branch → Save
5. Your app will be live at: https://YOUR-USERNAME.github.io/family-quran

## Install on Android
1. Open the link above in Chrome
2. Tap the banner "Install Family Quran" OR
3. Tap 3-dot menu ⋮ → "Add to Home screen"

## Install on iPhone
1. Open the link in Safari
2. Tap Share ⬆️ → "Add to Home Screen" → Add

بارك الله فيكم 🤲
